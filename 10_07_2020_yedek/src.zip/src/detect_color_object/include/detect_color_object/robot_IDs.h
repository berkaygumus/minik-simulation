//color id: top color, bottom color

const int numrobots = 3;
const int robIDList[3][2] = {{2,0},{1,0},{0,1}};

// HLOW,SLOW,VLOW, HHIGH, SHIGH, VHIGH
// Robot colors
/*const int HSVCOLOR1_RANGE[6] ={7,69,86,28,255,255};//yellow //{30,72,78,68,189,255};//{20,46,81,70,189,255};//{32,59,37,82,254,255};//green {42,22,55,84,189,255};
const int HSVCOLOR2_RANGE[6] ={30,72,78,68,189,255};//green //{100,45,56,139,149,247};//{99,0,40,179,114,255};//{16,115,0,33,235,255};//yellow {93,41,167,146,158,255};//HSVCOLOR1_RANGE[6] ={0,22,55,8,189,255};
const int HSVCOLOR3_RANGE[6] = {103,0,108,140,110,183}; //purple //{7,69,86,64,255,255};//{93,41,167,146,158,255};//blue {90,22,55,115,189,255};
const int HSVCOLOR4_RANGE[6] ={14,22,55,24,189,255};
const int HSVCOLOR5_RANGE[6] ={158,22,55,172,189,255};*/
