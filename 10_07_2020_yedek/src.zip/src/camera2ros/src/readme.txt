the number of pixels and square size in mm must be changed at default.xml and out_camera_data.xml files.
The image names must be changed at stereo_calib.xml file.

default.xml>>
<BoardSize_Width> 10</BoardSize_Width>
<BoardSize_Height>7</BoardSize_Height>

<!-- The size of a square in some user defined metric system (pixel, millimeter)-->
<Square_Size>24</Square_Size>

out_camera_data.xml>>
<board_width>10</board_width>
<board_height>7</board_height>
<square_size>24.</square_size>


"left01.jpg"
"right01.jpg"
"left02.jpg"
"right02.jpg"
"left03.jpg"
"right03.jpg"
"left04.jpg"
"right04.jpg"
"left05.jpg"
"right05.jpg"
"left06.jpg"
"right06.jpg"
"left07.jpg"
"right07.jpg"
"left08.jpg"
"right08.jpg"
"left09.jpg"
"right09.jpg"
"left10.jpg"
"right10.jpg"
"left11.jpg"
"right11.jpg"
"left12.jpg"
"right12.jpg"
"left13.jpg"
"right13.jpg"
"left14.jpg"
"right14.jpg"
"left15.jpg"
"right15.jpg"
"left16.jpg"
"right16.jpg"
"left17.jpg"
"right17.jpg"
"left18.jpg"
"right18.jpg"
"left19.jpg"
"right19.jpg"
"left20.jpg"
"right20.jpg"
"left21.jpg"
"right21.jpg"
"left22.jpg"
"right22.jpg"
"left23.jpg"
"right23.jpg"
